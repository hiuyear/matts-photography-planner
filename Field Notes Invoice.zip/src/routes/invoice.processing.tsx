import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { PageShell } from "@/components/PageShell";
import { loadMenu, saveExtraction, type Extraction } from "@/lib/menu-store";
import { extractInvoice } from "@/lib/extract.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/invoice/processing")({
  component: Processing,
});

function Processing() {
  const navigate = useNavigate();
  const ran = useRef(false);

  useEffect(() => {
    if (ran.current) return;
    ran.current = true;

    const menu = loadMenu();
    const transcript = sessionStorage.getItem("fieldinvoice.transcript");
    if (!menu || !transcript) {
      navigate({ to: "/invoice/new", replace: true });
      return;
    }

    (async () => {
      try {
        const result = (await extractInvoice({ data: { menu, transcript } })) as Extraction;
        // ensure every menu item exists in line_items
        const byId = new Map(result.line_items?.map((li) => [li.id, li]) ?? []);
        const lineItems = menu.menu.map((m) => {
          const found = byId.get(m.id);
          return (
            found ?? {
              id: m.id,
              label: m.label,
              selected: false,
              price: m.default_price,
              quantity: 1,
              price_source: "default" as const,
              source_quote: "",
            }
          );
        });
        saveExtraction({
          ...result,
          line_items: lineItems,
          tbd_items: result.tbd_items ?? [],
          client: result.client ?? { name: null, email: null },
          deposit_paid: result.deposit_paid ?? null,
          summary: result.summary ?? "",
        });
        navigate({ to: "/invoice/review", replace: true });
      } catch (e) {
        console.error(e);
        toast.error("Extraction failed", { description: (e as Error).message });
        navigate({ to: "/invoice/new", replace: true });
      }
    })();
  }, [navigate]);

  return (
    <PageShell>
      <div className="glass-card mt-12 rounded-2xl p-12 text-center">
        <div className="mb-4 flex justify-center gap-2 text-4xl">
          <span className="sparkle" style={{ animationDelay: "0s" }}>✨</span>
          <span className="sparkle" style={{ animationDelay: "0.3s" }}>🥂</span>
          <span className="sparkle" style={{ animationDelay: "0.6s" }}>✨</span>
        </div>
        <h1 className="shimmer-text font-display text-3xl">Reading the conversation…</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Mapping what was agreed against your menu.
        </p>
      </div>
    </PageShell>
  );
}
