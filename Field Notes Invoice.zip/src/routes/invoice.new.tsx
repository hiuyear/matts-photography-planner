import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageShell } from "@/components/PageShell";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { loadMenu } from "@/lib/menu-store";
import { DEMO_TRANSCRIPT } from "@/lib/demo-transcript";

export const Route = createFileRoute("/invoice/new")({
  component: NewInvoice,
});

function NewInvoice() {
  const navigate = useNavigate();
  const [transcript, setTranscript] = useState("");

  useEffect(() => {
    if (!loadMenu()) navigate({ to: "/onboarding/welcome", replace: true });
  }, [navigate]);

  function process() {
    if (!transcript.trim()) return;
    sessionStorage.setItem("fieldinvoice.transcript", transcript);
    navigate({ to: "/invoice/processing" });
  }

  return (
    <PageShell>
      <div className="glass-card rounded-2xl p-7">
        <div className="mb-1 flex items-center gap-2 text-sm font-medium text-[color:var(--gold)]">
          New invoice <span className="sparkle">✨</span>
        </div>
        <h1 className="font-display text-3xl">Drop in your consultation call</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Paste a transcript. We'll turn it into a draft invoice.
        </p>

        <div className="mt-5">
          <Textarea
            value={transcript}
            onChange={(e) => setTranscript(e.target.value)}
            placeholder="Paste the full call transcript here..."
            className="min-h-56 resize-y bg-white/70"
          />
          <button
            onClick={() => setTranscript(DEMO_TRANSCRIPT)}
            className="mt-2 text-xs text-muted-foreground underline hover:text-foreground"
          >
            🥂 Load demo transcript (Sarah & David)
          </button>
        </div>

        <div className="mt-6 flex items-center justify-between gap-3">
          <Link to="/">
            <Button variant="ghost" className="h-11">← Home</Button>
          </Link>
          <Button onClick={process} disabled={!transcript.trim()} className="btn-gold h-11 px-6">
            Process call →
          </Button>
        </div>
      </div>

      <div className="mt-4 rounded-xl border border-dashed border-[color:var(--silver)] bg-white/40 p-4 text-xs text-muted-foreground">
        Granola integration coming soon — for now, paste from your transcription tool of choice.
      </div>
    </PageShell>
  );
}
