import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  menu: z.any(),
  transcript: z.string().min(1),
});

const SYSTEM_PROMPT = `You are an invoicing assistant for a wedding photographer. You are given:
1. A price MENU as JSON (the only services with known prices).
2. A TRANSCRIPT of a client consultation call.

Map the conversation to the menu and produce a draft invoice.

Rules:
- For each menu item, decide if the client clearly agreed. Set "selected" true or false.
  If the client was non-committal ("maybe", "I'll think about it", "let me check"),
  treat it as NOT selected and add it to tbd_items.
- Use the menu default_price unless the photographer clearly quoted a different number
  on the call. If overridden, use the quoted number and set "price_source":"quoted".
- For per_hour or per_person items, fill "quantity" from the conversation. Default to 1
  if selected but no number was stated.
- If the client changed their mind, honor their FINAL decision in the call.
- If a service was discussed that is NOT on the menu, OR the photographer gave no price
  / said he would get back to you, do NOT guess. Add it to tbd_items with a short note
  and the exact quote.
- Extract client name and email if stated, else null. Extract deposit paid if mentioned (in dollars as a number), else null.
- Never invent a price. When unsure whether something was agreed, mark it TBD.
- Return ONLY valid JSON. No markdown, no commentary.

JSON schema:
{
  "client": { "name": string|null, "email": string|null },
  "line_items": [ { "id": string, "label": string, "selected": boolean, "price": number, "quantity": number, "price_source": "default"|"quoted", "source_quote": string } ],
  "tbd_items": [ { "label": string, "note": string, "source_quote": string } ],
  "deposit_paid": number|null,
  "summary": string
}

Include EVERY menu item in line_items (selected true or false). Keep menu item ids exactly.`;

export const extractInvoice = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");

    const userMsg = `MENU:\n${JSON.stringify(data.menu, null, 2)}\n\nTRANSCRIPT:\n${data.transcript}`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userMsg },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`AI gateway ${res.status}: ${txt.slice(0, 300)}`);
    }
    const json = (await res.json()) as { choices: { message: { content: string } }[] };
    let content = json.choices?.[0]?.message?.content ?? "{}";
    content = content.replace(/^```json\s*|\s*```$/g, "").trim();

    try {
      return JSON.parse(content);
    } catch {
      // one retry: ask for clean JSON
      const retry = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: "Return ONLY valid JSON matching the prior schema. No prose, no markdown." },
            { role: "user", content: content },
          ],
          response_format: { type: "json_object" },
        }),
      });
      const rj = (await retry.json()) as { choices: { message: { content: string } }[] };
      const c2 = (rj.choices?.[0]?.message?.content ?? "{}").replace(/^```json\s*|\s*```$/g, "").trim();
      return JSON.parse(c2);
    }
  });
